function validateForm() {
	return isNumeric("consumer Number",
			"Please enter a 6-digit consumer number!")
}
function isNumeric() {
	var consumer_number = document.getElementById(consumerNumber);
	var isValid = (inputValue.search(/[1-9][0-9]{5}/) !== -1);
	showMessage(isValid, inputElement);
	return isValid;
}