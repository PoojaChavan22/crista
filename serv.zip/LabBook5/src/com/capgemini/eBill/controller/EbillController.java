package com.capgemini.eBill.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.eBill.DTO.BillDTO;
import com.capgemini.eBill.DTO.Consumer;
import com.capgemini.eBill.exception.BillException;
import com.capgemini.eBill.service.EBillServiceImpl;
import com.capgemini.eBill.service.IEBillService;

@WebServlet("/EbillController")
public class EbillController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IEBillService service;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		
		super.init(config);
		
		service = new EBillServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String operation = request.getParameter("userAction");
		PrintWriter pw = response.getWriter();
		RequestDispatcher view = null;
		
		if (operation != null && "calculate".equals(operation)) 
		{
			String consumerNumberStr = request.getParameter("consumerNumber");
			int consumerNumber = Integer.valueOf(consumerNumberStr);
			String lastReadingStr = request.getParameter("lastReading");
			double lastReading = Double.valueOf(lastReadingStr);
			String currentReadingStr = request.getParameter("currentReading");
			double currentReading = Double.valueOf(currentReadingStr);
			
			Consumer consumer = null;
			try 
			{
				consumer = service.getConsumerDetails(consumerNumber);
				
			} 
			catch (BillException e) 
			{
				view = request.getRequestDispatcher("ErrorView.html");
				pw.println("Cannot show. Reason "+e.getMessage());
				view.include(request, response);
			}
			
			BillDTO bill = new BillDTO();
			
			//bill.setBillNumber(billNumber);
			double fixedCharge = 100;
			double unitConsumed = 0;
			unitConsumed = currentReading - lastReading;
			double netAmount = 0;
			netAmount = (unitConsumed * 1.15) + fixedCharge;
			
			bill.setConsumerNumber(consumerNumber);
			bill.setCurrentReading(currentReading);
			bill.setUnitConsumed(unitConsumed);
			bill.setNetAmount(netAmount);
			bill.setDate(java.sql.Date.valueOf(LocalDate.now()));
			
			try 
			{
				int records = service.addBill(bill);
				
			}
			catch(BillException e)
			{
				view = request.getRequestDispatcher("ErrorView.html");
				pw.println("Cannot show. Reason is "+e.getMessage());
				view.include(request, response);
			}
			if(consumer != null)
			{
			view = request.getRequestDispatcher("InfoView.html");
			pw.print("<h1>Welcome "+consumer.getConsumerName()+"</h1>");
			pw.println("");
			pw.print("<h1>Electricity Bill for Consumer Number- "+bill.getConsumerNumber()+" is</h1>");
			pw.println("");
			pw.print("<h1>Unit Consumed :: "+bill.getUnitConsumed()+"</h1>");
			pw.println("");
			pw.print("<h1>Net Amount :: Rs"+bill.getNetAmount()+"</h1>");
			view.include(request, response);
			}
			else
			{
				response.sendRedirect("ErrorView.html");
			}
			
			
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		
	}

}
