package com.capgemini.eBill.DTO;

/*consumer_num NUMBER(6) PRIMARY KEY, 
 * consumer_name VARCHAR2(20) NOT NULL, 
 * address VARCHAR2(30)
 */

public class Consumer 
{
	private int consumerNumber;
	private String consumerName;
	private String address;
	
	public Consumer() {
		super();
	}

	public Consumer(int consumerNumber, String consumerName, String address) {
		super();
		this.consumerNumber = consumerNumber;
		this.consumerName = consumerName;
		this.address = address;
	}

	public int getConsumerNumber() {
		return consumerNumber;
	}

	public void setConsumerNumber(int consumerNumber) {
		this.consumerNumber = consumerNumber;
	}

	public String getConsumerName() {
		return consumerName;
	}

	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Consumer [consumerNumber=" + consumerNumber + ", consumerName="
				+ consumerName + ", address=" + address + "]";
	}
}
