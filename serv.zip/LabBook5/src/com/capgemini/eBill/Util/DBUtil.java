package com.capgemini.eBill.Util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.eBill.exception.BillException;


public class DBUtil 
{
	static Connection connection;
	public static Connection obtainConnection() throws BillException
	{
	try
	{
		InitialContext context = new InitialContext();
		DataSource source = (DataSource) context.lookup("java:/jdbc/MyDS");
		connection = source.getConnection();
	}
	catch(NamingException e)
	{
		throw new BillException("Error while creating datasource. Reason is "+e.getMessage());
	}
	catch (SQLException e) 
	{
		throw new BillException("Error while obtaining connection. Reason is "+e.getMessage());
		
	}
		return connection;
	}
}
